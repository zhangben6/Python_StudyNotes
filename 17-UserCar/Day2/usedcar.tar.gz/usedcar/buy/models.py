from django.db import models
from userinfo.models import *
from sale.models import *
# Create your models here.
class Cart(models.Model):
    user = models.ForeignKey(UserInfo)
    car = models.ForeignKey(CarInfo)
    price = models.DecimalField(verbose_name='价格', max_digits=10, decimal_places=2)

    def __str__(self):
        return self.user.username
#
#
# 订单表Order
# id
# order_date 交易时间 Datetime
# price 交易价格 Decimal/C
# orderNo 订单号 C
# sale_user 卖家（Ｆ）
# buy_user 买家（Ｆ）？
#
# Orderdetails
# id
# order 订单（Ｆ）
# brand 品牌（Ｆ）
# ctitle 车辆名称 C
# regist_date 上牌日期 DateF
# engineNo 发动机号 C
# mileage 公里数 I
# maintenance_record 维修记录 Text
# price 期望售价 Decimal
# extreactprice 成交价格 Decimal
# newprice 新车价格 Decimal
# picture 图片 Image
# debt 债务 Cc
# other 第三方评估 Text
# promise 卖家承诺 Text