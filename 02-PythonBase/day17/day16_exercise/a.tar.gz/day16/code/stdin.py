# stdin.py


# 此示例示意标准输入文件
import sys
s = sys.stdin.readline()

print(s)