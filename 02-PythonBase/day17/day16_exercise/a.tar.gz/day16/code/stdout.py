# stdout.py


import sys
sys.stdout.write("hello world\n")
# sys.stdout.close()  # 不需要关闭

print("这是print打印出来的文字!") # 调用sys.stdout.write

